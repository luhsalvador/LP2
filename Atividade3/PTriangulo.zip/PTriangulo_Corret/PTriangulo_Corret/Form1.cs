﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo_Corret
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        private void mskbxLadoB_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnFechar)
            {
                return;
            }
            if (!double.TryParse(mskbxLadoB.Text, out ladoB) || (ladoB <= 0))
            {
                MessageBox.Show("Numero Invalido! Digite Novamente");
                Focus();
            }
        }

        private void mskbxLadoC_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnFechar)
            {
                return;
            }
            if (!double.TryParse(mskbxLadoC.Text, out ladoC) || (ladoC <= 0))
            {
                MessageBox.Show("Numero Invalido! Digite Novamente");
                Focus();
            }
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if ((ladoA < (ladoB + ladoC)) && (ladoA > (Math.Abs(ladoB - ladoC)) && 
                (ladoB < (ladoA + ladoC)) && (ladoB > (Math.Abs(ladoA - ladoC)) && 
                (ladoC < (ladoA + ladoB)) && (ladoC > (Math.Abs(ladoA - ladoB))))))
            {
        
                if (ladoA == ladoB && ladoB == ladoC)
                    MessageBox.Show("Triangulo Equilatero");
                else if (ladoA == ladoB || ladoC == ladoB || ladoC == ladoA)
                    MessageBox.Show("Triangulo Isosceles");
                else
                    MessageBox.Show("Triangulo Escaleno");
            }

        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void mskbxLadoA_Validated(object sender, EventArgs e)
        {
            if(this.ActiveControl == btnFechar)
            {
                return;
            }
            if(!double.TryParse(mskbxLadoA.Text, out ladoA) || (ladoA <= 0))
            {
                MessageBox.Show("Numero Invalido! Digite Novamente");
                Focus();
            }
                
        }
    }
}
