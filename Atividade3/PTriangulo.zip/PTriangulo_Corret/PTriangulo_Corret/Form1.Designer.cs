﻿namespace PTriangulo_Corret
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLadoA = new System.Windows.Forms.Label();
            this.lblLadoB = new System.Windows.Forms.Label();
            this.lblLadoC = new System.Windows.Forms.Label();
            this.mskbxLadoA = new System.Windows.Forms.MaskedTextBox();
            this.mskbxLadoB = new System.Windows.Forms.MaskedTextBox();
            this.mskbxLadoC = new System.Windows.Forms.MaskedTextBox();
            this.btnExecutar = new System.Windows.Forms.Button();
            this.btnFechar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblLadoA
            // 
            this.lblLadoA.AutoSize = true;
            this.lblLadoA.Location = new System.Drawing.Point(27, 66);
            this.lblLadoA.Name = "lblLadoA";
            this.lblLadoA.Size = new System.Drawing.Size(46, 13);
            this.lblLadoA.TabIndex = 0;
            this.lblLadoA.Text = "LADO A";
            // 
            // lblLadoB
            // 
            this.lblLadoB.AutoSize = true;
            this.lblLadoB.Location = new System.Drawing.Point(27, 122);
            this.lblLadoB.Name = "lblLadoB";
            this.lblLadoB.Size = new System.Drawing.Size(46, 13);
            this.lblLadoB.TabIndex = 1;
            this.lblLadoB.Text = "LADO B";
            // 
            // lblLadoC
            // 
            this.lblLadoC.AutoSize = true;
            this.lblLadoC.Location = new System.Drawing.Point(27, 180);
            this.lblLadoC.Name = "lblLadoC";
            this.lblLadoC.Size = new System.Drawing.Size(46, 13);
            this.lblLadoC.TabIndex = 2;
            this.lblLadoC.Text = "LADO C";
            // 
            // mskbxLadoA
            // 
            this.mskbxLadoA.Location = new System.Drawing.Point(154, 59);
            this.mskbxLadoA.Mask = "00.00";
            this.mskbxLadoA.Name = "mskbxLadoA";
            this.mskbxLadoA.Size = new System.Drawing.Size(100, 20);
            this.mskbxLadoA.TabIndex = 3;
            this.mskbxLadoA.Validated += new System.EventHandler(this.mskbxLadoA_Validated);
            // 
            // mskbxLadoB
            // 
            this.mskbxLadoB.Location = new System.Drawing.Point(154, 114);
            this.mskbxLadoB.Mask = "00.00";
            this.mskbxLadoB.Name = "mskbxLadoB";
            this.mskbxLadoB.Size = new System.Drawing.Size(100, 20);
            this.mskbxLadoB.TabIndex = 4;
            this.mskbxLadoB.Validated += new System.EventHandler(this.mskbxLadoB_Validated);
            // 
            // mskbxLadoC
            // 
            this.mskbxLadoC.Location = new System.Drawing.Point(154, 172);
            this.mskbxLadoC.Mask = "00.00";
            this.mskbxLadoC.Name = "mskbxLadoC";
            this.mskbxLadoC.Size = new System.Drawing.Size(100, 20);
            this.mskbxLadoC.TabIndex = 5;
            this.mskbxLadoC.Validated += new System.EventHandler(this.mskbxLadoC_Validated);
            // 
            // btnExecutar
            // 
            this.btnExecutar.Location = new System.Drawing.Point(30, 232);
            this.btnExecutar.Name = "btnExecutar";
            this.btnExecutar.Size = new System.Drawing.Size(100, 71);
            this.btnExecutar.TabIndex = 6;
            this.btnExecutar.Text = "EXECUTAR";
            this.btnExecutar.UseVisualStyleBackColor = true;
            this.btnExecutar.Click += new System.EventHandler(this.btnExecutar_Click);
            // 
            // btnFechar
            // 
            this.btnFechar.Location = new System.Drawing.Point(154, 232);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(100, 71);
            this.btnFechar.TabIndex = 7;
            this.btnFechar.Text = "FECHAR";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(294, 341);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.btnExecutar);
            this.Controls.Add(this.mskbxLadoC);
            this.Controls.Add(this.mskbxLadoB);
            this.Controls.Add(this.mskbxLadoA);
            this.Controls.Add(this.lblLadoC);
            this.Controls.Add(this.lblLadoB);
            this.Controls.Add(this.lblLadoA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLadoA;
        private System.Windows.Forms.Label lblLadoB;
        private System.Windows.Forms.Label lblLadoC;
        private System.Windows.Forms.MaskedTextBox mskbxLadoA;
        private System.Windows.Forms.MaskedTextBox mskbxLadoB;
        private System.Windows.Forms.MaskedTextBox mskbxLadoC;
        private System.Windows.Forms.Button btnExecutar;
        private System.Windows.Forms.Button btnFechar;
    }
}

