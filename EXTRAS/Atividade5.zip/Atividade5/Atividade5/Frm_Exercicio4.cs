﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }
        private void btnSalarioBruto_Click(object sender, EventArgs e)
        {
            string nome;
            int producao;
            double salario, gratificacao, salarioBruto;
            int B = 0, C = 0, D = 0;

            nome = txtNome.Text;
            producao = Convert.ToInt32(txtProducao.Text);
            salario = Convert.ToDouble(txtSalario.Text);
            gratificacao = Convert.ToDouble(txtGratificacao.Text);

            if (producao >= 100)
            {
                B = 1;
            }

            if (producao >= 120)
            {
                C = 1;
            }

            if (producao >= 150)
            {
                D = 1;
            }
            salarioBruto = salario + (salario * ((0.05 * B) + (0.10 * C) + (1 * D)));

            if (salarioBruto > 7000)
            {
                if (producao >= 150 && gratificacao > 0)
                {
                    MessageBox.Show("Funcionário: " + nome + "\nSalário Bruto: R$ " + salarioBruto.ToString("F2"));
                }
                else
                {
                    salarioBruto = 7000;
                    MessageBox.Show("Funcionário: " + nome + "\nSalário limitado em R$ 7000,00" + "\nSalário Bruto: R$ " + salarioBruto.ToString("F2"));
                }
            }
            else
            {
                MessageBox.Show("Funcionário: " + nome + "\nSalário Bruto: R$ " + salarioBruto.ToString("F2"));
            }
        }

        private void Frm_Exercicio4_Load(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Text = "";
            txtMatricula.Text = "";
            txtProducao.Text = "";
            txtSalario.Text = "";
            txtGratificacao.Text = "";
            txtNome.Focus();
        }
    }
}
