﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace PAluno01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            //lstboxMedia.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] medias = new double[5, 3];
            double[] mediaGeral = new double[5];
            double mediaSala = 0;
            string[] nomeAluno = { "Paula", "Jana", "Berta", "Denis", "Pedro"};
            string[] nomeProf = { "Ana", "Dimas", "Levi" };
            int i, j;

            for(i = 0; i < 5; i++)
            {
                for(j = 0; j < 3; j++)
                {
                    string aux = Interaction.InputBox($"Aluno(a) {nomeAluno[i]}\nDigite as notas {j} do professor {nomeProf[i]}", "Entrada de Notas\n");
                    
                    if(!Double.TryParse(aux, out medias[i, j]) || (medias[i, j] <= 0))
                    {
                        MessageBox.Show("Nota Invalida");
                        j--;
                    }
                    else
                    {
                        mediaGeral[i] += medias[i, j];
                        mediaSala += medias[i,j] / 15;
                    }
                    

                    lstboxMedia.Items.Clear();
                    //for(int i = 0; i < 5; i++)
                    {
                        lstboxMedia.Items.Add($"\nNotas Prof. {nomeProf[i]}");
                        lstboxMedia.Items.Add($"{nomeAluno[i]} = {medias[i,j]}");
                        lstboxMedia.Items.Add("_________________________");
                        lstboxMedia.Items.Add("Media por professor");
                        lstboxMedia.Items.Add($"Prof. {nomeProf[i]}:{nomeAluno[i]} = {medias[i,j]}");
                        lstboxMedia.Items.Add("_________________________");
                        lstboxMedia.Items.Add("Media geral da sala");
                        lstboxMedia.Items.Add($"A média geral de todos os alunos foi de:{mediaSala}");

                    }

                    


                }
                
            }
        }
    }
}
